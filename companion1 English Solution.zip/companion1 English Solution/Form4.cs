﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace companion1
{
    public partial class Form4 : Form
    {

        public Form4()
        {
            InitializeComponent();
        }
        public string connectionString = @"Data Source=DESKTOP-P7D4JFE\AMIRREZA;Initial Catalog=Dustan;Integrated Security=True";

        private void dustanTableBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dustanTableBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dustanDataSet);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dustanDataSet.dustanTable' table. You can move, or remove it, as needed.
            // this.dustanTableTableAdapter.Fill(this.dustanDataSet.dustanTable);
            display_data();









        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (textBox1.Text + textBox2.Text + textBox3.Text == "")
            {
                MessageBox.Show("Please fill the ID,Persons Name and Mobil Number");
            }




            if (textBox1.Text + textBox2.Text + textBox3.Text != null)
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {
                    string q = "insert into dustanTable(ID,FriendsName,MobileNumber)values('" + textBox1.Text.ToString() + "','" + textBox2.Text.ToString() + "','" + textBox3.Text.ToString() + "')";
                    SqlCommand cmd = new SqlCommand(q, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    display_data();
                    MessageBox.Show("Added Successfully");
                }
                else if (textBox1.Text == "")
                {
                    MessageBox.Show("Please fill ID");
                }
                else if (textBox2.Text == "")
                {
                    MessageBox.Show("Please fill Persons Name");
                }
                else if (textBox3.Text == "")
                {
                    MessageBox.Show("Please fill Mobile Number");

                }


            }
        }






        public void display_data()
        {
            try
            {
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {
                    string q = "select * from dustanTable";
                    SqlCommand cmd = new SqlCommand(q, con);
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    sda.Fill(dt);
                    dustanTableDataGridView.DataSource = dt;
                    con.Close();
                }

            }
            catch (Exception ex)
            {
                ex.ToString();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q = "delete from dustanTable where FriendsName='" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.ExecuteNonQuery();
                con.Close();
                display_data();
                MessageBox.Show("Deleted Successfully");


            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string q = "select * from dustanTable where FriendsName='" + textBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dustanTableDataGridView.DataSource = dt;
                con.Close();
                
            }
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            display_data();
        }
    }
}
