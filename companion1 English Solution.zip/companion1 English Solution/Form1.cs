﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace companion1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {


            try
            {
                label12.Visible = true;
                list_of_experience_period.Visible = true;
                //
              

                    if (list_of_experience_period.Text == "1 week")
                    {


                        if (((comboBox1.Text == "Sensitive" && comboBox2.Text == "Health") || (comboBox1.Text == "Tender" && comboBox2.Text == "Health"))

                        || (comboBox1.Text == "Passionate" && comboBox2.Text == "Health"))
                        {
                            switch (linkLabel1.Text = "please dance for a quarter")
                            {
                                case "a":

                                    break;


                            }

                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=========================================================================================
                        }
                        else if (((comboBox1.Text == "Sensitive" && comboBox2.Text == "Education") || (comboBox1.Text == "Tender" && comboBox2.Text == "Education"))

                            || (comboBox1.Text == "Passionate" && comboBox2.Text == "Education"))
                        {

                            switch (linkLabel1.Text = "find a friend for yourself")
                            {
                                case "b":

                                    break;


                            }
                            //============================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline with your friend")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water and study")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth and drink a cup of coffee")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river 20 min")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river 20 min")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim 20 min")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "dance 10 min at home,take a bath,sleep enough")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking for 1 hour")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=======================================================================================================
                        }
                        else if (((comboBox1.Text == "Sensitive" && comboBox2.Text == "Travel") || (comboBox1.Text == "Tender" && comboBox2.Text == "Travel"))

                            || (comboBox1.Text == "Passionate" && comboBox2.Text == "Travel"))
                        {

                            switch (linkLabel1.Text = "find a friend for yourself")
                            {
                                case "c":

                                    break;


                            }
                            //========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "go to a casino or disco and enjoy")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth and go to a disco")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river or sea")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate 15 min")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "put on warm cloth")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at hotel")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at hotel")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at hotel")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=========================================================================================


                        }
                        else if (((comboBox1.Text == "Sensitive" && comboBox2.Text == "Bussiness") || (comboBox1.Text == "Tender" && comboBox2.Text == "Bussiness"))

                            || (comboBox1.Text == "Passionate" && comboBox2.Text == "Bussiness"))
                        {

                            switch (linkLabel1.Text = "consult with an expert or psychologist")
                            {
                                case "d":

                                    break;


                            }
                            //========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "drink a glass of lemon juice")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside with your cosultant and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "take a break and drink 2 cup of tea(only 2 cup)")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "stay in office and draw future schedule & wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "open a window and take breathe")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside with your team and hold a meeting")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "accompany with your consultant")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe for 20 min")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min with your Customer")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "stay at office and drink a glass of juice")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "drink a cup of tea")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "dont make a decision,cosult with your cosultant")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate at office")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "dont make a sensitive decision")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "drink a glass of orange juice")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //============================================================================================
                        }
                        else if (((comboBox1.Text == "Irritated" && comboBox2.Text == "Education") || (comboBox1.Text == "Nervous" && comboBox2.Text == "Education"))

                            || (comboBox1.Text == "Provoked" && comboBox2.Text == "Education"))
                        {

                            switch (linkLabel1.Text = "consult with your teacher rapidly")
                            {
                                case "a":

                                    break;


                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside for 20 min")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate for 15 min")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "go to a park and play a game")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //============================================================================================

                        }
                        else if (((comboBox1.Text == "Irritated" && comboBox2.Text == "Sports") || (comboBox1.Text == "Nervous" && comboBox2.Text == "Sports"))

                            || (comboBox1.Text == "Provoked" && comboBox2.Text == "Sports"))
                        {

                            switch (linkLabel1.Text = "take three deep breath,continue carefully")
                            {
                                case "a":

                                    break;


                            }
                            //===========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and exercize at home")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drink a lot of fruit")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at gym")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "dont go outside and drink a lot of water")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //==============================================================================================
                        }
                        else if (((comboBox1.Text == "Irritated" && comboBox2.Text == "Bussiness") || (comboBox1.Text == "Nervous" && comboBox2.Text == "Bussiness"))

                            || (comboBox1.Text == "Provoked" && comboBox2.Text == "Bussiness"))
                        {

                            switch (linkLabel1.Text = "take three deep breath and dont make a decision")
                            {
                                case "b":

                                    break;
                                    //========================================================================================

                            }
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "accompany with your consultant")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "drink hot chocolate")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "open the window and take three deep breathe")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "relax your body and sit down")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "go and swim after work")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside for 10 min")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "watch T.V for 20 min")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club at night and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet for 10 min,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate on your seat for 5 min")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "cosult with your psychologist")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea with your team")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "walk an breathe for 3 min")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from your life and do meditate")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //===============================================================================================


                        }
                        else if (((comboBox1.Text == "Irritated" && comboBox2.Text == "Health") || (comboBox1.Text == "Nervous" && comboBox2.Text == "Health"))

                            || (comboBox1.Text == "Provoked" && comboBox2.Text == "Health"))
                        {

                            switch (linkLabel1.Text = "take three deep breath and meditate")
                            {
                                case "c":

                                    break;


                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //========================================================================================
                        }

                        else if (comboBox1.Text == "Bored‌" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "meditate and have a fun")
                            {
                                case "a":

                                    break;


                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth and dance in a club")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "watch a documentary movie")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,listen to a happy music")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,eat necessary food")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //============================================================================================

                        }
                        else if (comboBox1.Text == "Bored‌" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "meditate and have a fun")
                            {
                                case "b":

                                    break;


                            }
                            //=================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "do meditation on your seat")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth,drink hot chocolate")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "do meditate 5 min on your seat,paly a music")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river after work")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim after work")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and review your schedule")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside after work and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "meditate 5 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and review your schedule")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour after work")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside with your customer")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate for 5 min")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "listen to a happy music")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "do your interesting work")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "listen to a funny music")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and Held up a seminar")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //================================================================================================

                        }

                        else if (comboBox1.Text == "Discouraged" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "consult with a Motivational Consultant")
                            {
                                case "a":

                                    break;


                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "go to a night club and dance")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //===============================================================================================

                        }
                        else if (comboBox1.Text == "Discouraged" && comboBox2.Text == "Sports")
                        {

                            switch (linkLabel1.Text = "consult with a Motivational Consultant")
                            {
                                case "b":

                                    break;


                            }
                            //================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=============================================================================================

                        }
                        else if (comboBox1.Text == "Discouraged" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "consult with a Economic Consultant")
                            {
                                case "c":

                                    break;

                                    //====================================================================================================================
                            }
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water,dance 30 min")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "walk for 20 min")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth and write your thought")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "listen to a happy music")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river after work")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "Its possible and you can,Listen to a few happy music")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside with your customer")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe if possible")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "walk and think correctly")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour after work")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life,you will become only wet!")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate on your seat")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "accompany with your consultant")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go to a restaurant and drink a cup of tea with your customer")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go to a think room with your customer")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office,drink 2 cup of tea")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //================================================================================================

                        }
                        else if (comboBox1.Text == "Discouraged" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "Hopeful more and more,Try Uninterrupted")
                            {
                                case "d":

                                    break;


                            }
                            //=================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //===========================================================================================


                        }
                        else if (comboBox1.Text == "Doubtful" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "consult with an expert")
                            {
                                case "a":

                                    break;


                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=============================================================================================
                        }
                        else if (comboBox1.Text == "Doubtful" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "consult with a psychologist first")
                            {
                                case "b":

                                    break;


                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //===============================================================================================


                        }

                        else if (((comboBox1.Text == "Uncertain" && comboBox2.Text == "Education") ||
                            (comboBox1.Text == "Perplexed" && comboBox2.Text == "Education")) ||
                        (comboBox1.Text == "Empty" && comboBox2.Text == "Education") ||
                            (comboBox1.Text == "Vulnerable" && comboBox2.Text == "Education") ||
                            (comboBox1.Text == "Bad" && comboBox2.Text == "Education") ||
                            (comboBox1.Text == "Disgusted" && comboBox2.Text == "Education"))
                        {

                            switch (linkLabel1.Text = "consult with an expert psychologist or consultant")
                            {
                                case "a":
                                    break;
                            }

                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================

                        }

                        else if (((comboBox1.Text == "Uncertain" && comboBox2.Text == "Bussiness") ||
                            (comboBox1.Text == "Perplexed" && comboBox2.Text == "Bussiness")) ||
                        (comboBox1.Text == "Empty" && comboBox2.Text == "Bussiness") ||
                            (comboBox1.Text == "Vulnerable" && comboBox2.Text == "Bussiness") ||
                            (comboBox1.Text == "Bad" && comboBox2.Text == "Bussiness") ||
                            (comboBox1.Text == "Disgusted" && comboBox2.Text == "Bussiness"))
                        {
                            switch (linkLabel1.Text = "consult with an expert consultant")
                            {
                                case "b":
                                    break;
                            }

                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline after work")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour after work")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside of your room and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking for 15 min")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //===========================================================================================
                        }

                        else if ((((comboBox1.Text == "Uncertain" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Perplexed" && comboBox2.Text == "Health")) ||
                        (comboBox1.Text == "Empty" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Vulnerable" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Bad" && comboBox2.Text == "Health")) ||
                            (comboBox1.Text == "Disgusted" && comboBox2.Text == "Health"))
                        {
                            switch (linkLabel1.Text = "consult with an expert psychologist")
                            {
                                case "c":
                                    break;
                            }

                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================


                        }

                        else if ((comboBox1.Text == "Neutral" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Insensitive" && comboBox2.Text == "Health"))
                        {

                            switch (linkLabel1.Text = "consult with a psychologist first")
                            {
                                case "a":

                                    break;


                            }
                            //========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================

                        }

                        else if ((comboBox1.Text == "Fearful" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Terrified" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Panic" && comboBox2.Text == "Health"))
                        {

                            switch (linkLabel1.Text = "consult with a psychologist first")
                            {
                                case "a":

                                    break;

                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=================================================================================================

                        }

                        else if (((comboBox1.Text == "Fearful" && comboBox2.Text == "Education") ||
                            (comboBox1.Text == "Sorrowful" && comboBox2.Text == "Education") ||
                            (comboBox1.Text == "Grief" && comboBox2.Text == "Education")) ||
                            (comboBox1.Text == "Upset" && comboBox2.Text == "Education"))
                        {

                            switch (linkLabel1.Text = "Listen to a happy music,this is those frequency that you attract!")
                            {
                                case "a":

                                    break;

                            }

                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "change your position and drink a glass of water")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================

                        }
                        else if (((comboBox1.Text == "Fearful" && comboBox2.Text == "Bussiness") ||
                           (comboBox1.Text == "Sorrowful" && comboBox2.Text == "Bussiness") ||
                           (comboBox1.Text == "Grief" && comboBox2.Text == "Bussiness")) ||
                           (comboBox1.Text == "Upset" && comboBox2.Text == "Bussiness"))
                        {

                            switch (linkLabel1.Text = "drink a cup of tea,then take decision")
                            {
                                case "b":

                                    break;

                            }
                            //=============================================================================================

                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline after work about 15 min")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim after work")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside after work")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a disco and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life about 5 min")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at think room")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside of the room and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //===============================================================================================

                        }

                        else if (((comboBox1.Text == "Fearful" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Sorrowful" && comboBox2.Text == "Health") ||
                            (comboBox1.Text == "Grief" && comboBox2.Text == "Health")) ||
                            (comboBox1.Text == "Upset" && comboBox2.Text == "Health"))
                        {

                            switch (linkLabel1.Text = "consult with a psychologist first")
                            {
                                case "c":

                                    break;

                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================
                        }
                        else if (comboBox1.Text == "Pained" && comboBox2.Text == "Sports")
                        {

                            switch (linkLabel1.Text = "visit a doctor to be better then continue")
                            {
                                case "a":

                                    break;

                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "walk a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "study more")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate 30 min")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //===========================================================================================


                        }
                        else if (comboBox1.Text == "Pained" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "Health is more important,then continue to Educate")
                            {
                                case "a":

                                    break;

                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================

                        }

                        else if (comboBox1.Text == "Pained" && comboBox2.Text == "Travel")
                        {

                            switch (linkLabel1.Text = "Health is more important,then continue to Travel")
                            {
                                case "b":

                                    break;

                            }
                            //=========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at Hotel")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at Hotel")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at Hotel")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at Hotel")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //==============================================================================================

                        }

                        else if (comboBox1.Text == "Pained" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "Health is more important,then continue to Bussiness")
                            {
                                case "c":

                                    break;

                            }
                            //===========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline after work")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================

                        }

                        else if (comboBox1.Text == "Pained" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "visit a doctor,keep calm,drink your drugs on time")
                            {
                                case "d":

                                    break;

                            }
                            //===============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "walk or spend a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================

                        }

                        else if (comboBox1.Text == "Weary" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "dance for a quarter")
                            {
                                case "a":

                                    break;

                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go to a disco at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "eat some fresh fruit")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================


                        }
                        else if (comboBox1.Text == "Weary" && comboBox2.Text == "sports")
                        {

                            switch (linkLabel1.Text = "rest more")
                            {
                                case "b":

                                    break;

                            }
                            //===============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "continue to exercise")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================

                        }
                        else if (comboBox1.Text == "Weary" && comboBox2.Text == "Travel")
                        {

                            switch (linkLabel1.Text = "go to a CASINO or Disco and dance")
                            {
                                case "c":

                                    break;

                            }
                            //===============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at Hotel and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at Hotel")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at Hotel")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at Hotel")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================


                        }
                        else if (comboBox1.Text == "Weary" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "drink a cup of coffee")
                            {
                                case "d":

                                    break;

                            }
                            //===============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline after work")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river after work")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river after work")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim after work")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home about psychology")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour after work")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside of your room and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside of your room and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================

                        }
                        else if (comboBox1.Text == "Weary" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "sleep enough at night and listen to a happy music")
                            {
                                case "e":

                                    break;

                            }
                            //================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and enjoy")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==================================================================================================
                        }




                        else if (((((comboBox1.Text == "Anxious" && comboBox2.Text == "Education") ||
                                    (comboBox1.Text == "Anguish" && comboBox2.Text == "Education") ||
                                    (comboBox1.Text == "Concerned" && comboBox2.Text == "Education")) ||
                                    (comboBox1.Text == "Worried" && comboBox2.Text == "Education")) ||
                                    (comboBox1.Text == "Uneasy" && comboBox2.Text == "Education")) ||
                                    (comboBox1.Text == "Distressed" && comboBox2.Text == "Education"))
                        {

                            switch (linkLabel1.Text = "have a plan for your future")
                            {
                                case "a":

                                    break;

                            }
                            //================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //===========================================================================================
                        }

                        else if (((((comboBox1.Text == "Anxious" && comboBox2.Text == "Bussiness") ||
                                    (comboBox1.Text == "Anguish" && comboBox2.Text == "Bussiness") ||
                                    (comboBox1.Text == "Concerned" && comboBox2.Text == "Bussiness")) ||
                                    (comboBox1.Text == "Worried" && comboBox2.Text == "Bussiness")) ||
                                    (comboBox1.Text == "Uneasy" && comboBox2.Text == "Bussiness")) ||
                                    (comboBox1.Text == "Distressed" && comboBox2.Text == "Bussiness"))
                        {

                            switch (linkLabel1.Text = "check your notes,read success books")
                            {
                                case "b":

                                    break;

                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river after work")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim after work")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "dont drive car")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //=============================================================================================


                        }


                        //=============================================================================================

                        else if (((((comboBox1.Text == "Anxious" && comboBox2.Text == "Health") ||
                                    (comboBox1.Text == "Anguish" && comboBox2.Text == "Health") ||
                                    (comboBox1.Text == "Concerned" && comboBox2.Text == "Health")) ||
                                    (comboBox1.Text == "Worried" && comboBox2.Text == "Health")) ||
                                    (comboBox1.Text == "Uneasy" && comboBox2.Text == "Health")) ||
                                    (comboBox1.Text == "Distressed" && comboBox2.Text == "Health"))
                        {

                            switch (linkLabel1.Text = "consult with a psychologist first")
                            {
                                case "d":

                                    break;

                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================

                        }
                        else if (comboBox1.Text == "Aching" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "no pain,no gain")
                            {
                                case "a":

                                    break;

                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //============================================================================================

                        }
                        else if (comboBox1.Text == "Aching" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "no pain,no gain")
                            {
                                case "b":

                                    break;

                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================


                        }
                        else if (comboBox1.Text == "Aching" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "be patient,your situation will be change")
                            {
                                case "c":

                                    break;

                            }
                            //===============================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //=============================================================================================
                        }
                        else if (comboBox1.Text == "Lonely" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "find for yourself a companion")
                            {
                                case "a":

                                    break;

                            }
                            //===============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==========================================================================================


                        }
                        else if (comboBox1.Text == "Lonely" && comboBox2.Text == "Sports")
                        {

                            switch (linkLabel1.Text = "find for yourself a mate")
                            {
                                case "b":

                                    break;

                            }
                            //========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //================================================================================================

                        }
                        else if (comboBox1.Text == "Lonely" && comboBox2.Text == "Travel")
                        {

                            switch (linkLabel1.Text = "find for yourself a mate")
                            {
                                case "c":

                                    break;

                            }
                            //======================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //==============================================================================================

                        }
                        else if (comboBox1.Text == "Lonely" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "find for yourself a mate")
                            {
                                case "d":

                                    break;

                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //========================================================================================

                        }
                        else if (comboBox1.Text == "Lonely" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "find for yourself a mate")
                            {
                                case "e":

                                    break;

                            }
                            //==========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }

                            }


                            //======================================================================================

                        }
                        else if (comboBox1.Text == "Disinterested" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "leave it and find your interesting thing")
                            {
                                case "a":

                                    break;

                            }
                            //=========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //==============================================================================================

                        }
                        else if (comboBox1.Text == "Disinterested" && comboBox2.Text == "Sports")
                        {

                            switch (linkLabel1.Text = "leave it and find your interesting sport")
                            {
                                case "b":

                                    break;

                            }
                            //=========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================

                        }
                        else if (comboBox1.Text == "Disinterested" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "leave it and find your interesting thing")
                            {
                                case "c":

                                    break;

                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at offce")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //============================================================================================

                        }
                        else if (comboBox1.Text == "Disinterested" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "do right thing and consult with an expert")
                            {
                                case "d":

                                    break;

                            }
                            //==============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //===========================================================================================
                        }
                        else if (comboBox1.Text == "Pessimistic" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "change your view and rest your mind")
                            {
                                case "a":

                                    break;

                            }
                            //===========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================
                        }
                        else if (comboBox1.Text == "Pessimistic" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "change your view and rest your mind and consult")
                            {
                                case "b":

                                    break;

                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at office and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //=============================================================================================

                        }
                        else if (comboBox1.Text == "Pessimistic" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "change your view and rest your mind and consult")
                            {
                                case "c":

                                    break;

                            }
                            //============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //=============================================================================================
                        }
                        else if (comboBox1.Text == "Preoccupied" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "attend to your PSYCHE,consult with an expert")
                            {
                                case "a":

                                    break;

                            }
                            //================================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //=============================================================================================

                        }
                        else if (comboBox1.Text == "Preoccupied" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "attend to your PSYCHE,consult with an expert")
                            {
                                case "b":

                                    break;

                            }
                            //=========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at office")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //==========================================================================================


                        }
                        else if (comboBox1.Text == "Preoccupied" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "attend to your PSYCHE,Meditate")
                            {
                                case "c":

                                    break;

                            }
                            //==========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }
                            //=============================================================================================

                        }
                        else if (comboBox1.Text == "Mournful" && comboBox2.Text == "Education")
                        {

                            switch (linkLabel1.Text = "attend to your PSYCHE,Meditate")
                            {
                                case "a":

                                    break;

                            }
                            //=========================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //========================================================================================

                        }

                        else if (comboBox1.Text == "Mournful" && comboBox2.Text == "Bussiness")
                        {

                            switch (linkLabel1.Text = "attend to your PSYCHE,consult with an expert")
                            {
                                case "b":

                                    break;

                            }
                            //=======================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at office and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at office")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at office")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //============================================================================================

                        }
                        else if (comboBox1.Text == "Mournful" && comboBox2.Text == "Health")
                        {

                            switch (linkLabel1.Text = "attend to your PSYCHE,Meditate")
                            {
                                case "c":

                                    break;

                            }
                            //=============================================================================================
                            if (weather_cmb.Text == "Equatorial")
                            {
                                switch (linkLabel1.Text = "dance a quarter near the coastline")
                                {

                                    case "a":

                                        break;

                                }

                            }

                            else if (weather_cmb.Text == "Extreme(hot / cold)")
                            {
                                switch (linkLabel1.Text = "stay at home and drink enough water")
                                {
                                    case "b":
                                        break;
                                }
                            }
                            else if (weather_cmb.Text == "Moderate")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "c":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cool")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 minute")
                                {
                                    case "d":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cold")
                            {
                                switch (linkLabel1.Text = "wear a warm cloth")
                                {
                                    case "e":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Freezing")
                            {
                                switch (linkLabel1.Text = "eat warm soup or drink hot chocolate")
                                {
                                    case "f":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mild")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "g":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunny")
                            {
                                switch (linkLabel1.Text = "go outside and dance near the river")
                                {
                                    case "h":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Humid") || (weather_cmb.Text == "damp") || (weather_cmb.Text == "moist"))
                            {
                                switch (linkLabel1.Text = "dance near the sea and swim")
                                {
                                    case "i":
                                        break;

                                }
                            }
                            else if ((weather_cmb.Text == "Dry") || (weather_cmb.Text == "Warm") || (weather_cmb.Text == "Hot") || (weather_cmb.Text == "Scorcher"))
                            {
                                switch (linkLabel1.Text = "drink enough water")
                                {
                                    case "j":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Mist")
                            {
                                switch (linkLabel1.Text = "put on warm cloth and go outside")
                                {
                                    case "k":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Clear")
                            {
                                switch (linkLabel1.Text = "go for walking outside and take deep breathe")
                                {
                                    case "l":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Stormy")
                            {
                                switch (linkLabel1.Text = "stay at home and drink two cup of coffee(only 2 cup )")
                                {
                                    case "m":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Changeable")
                            {
                                switch (linkLabel1.Text = "go outside and walk for 20 min")
                                {
                                    case "n":
                                        break;

                                }
                            }

                            else if ((weather_cmb.Text == "Muggy") || (weather_cmb.Text == "Stifling"))
                            {
                                switch (linkLabel1.Text = "go outside at night and study at home")
                                {
                                    case "o":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Cloudy")
                            {
                                switch (linkLabel1.Text = "go to a club and dance 1 hour")
                                {
                                    case "p":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Rainy")
                            {
                                switch (linkLabel1.Text = "go outside and become wet,Enjoy From Life")
                                {
                                    case "q":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Windy")
                            {
                                switch (linkLabel1.Text = "do Meditate")
                                {
                                    case "r":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Foggy")
                            {
                                switch (linkLabel1.Text = "drive slowly and carefully")
                                {
                                    case "s":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunder and lighting")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "t":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hurricane – typhoon")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside")
                                {
                                    case "u":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstone")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "v":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Hailstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "w":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Thunderstorm")
                            {
                                switch (linkLabel1.Text = "be careful and dont go outside,Enjoy at home")
                                {
                                    case "x":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Snowy")
                            {
                                switch (linkLabel1.Text = "go outside and drink a cup of tea")
                                {
                                    case "y":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Sunshine")
                            {
                                switch (linkLabel1.Text = "go outside and enjoy from walking")
                                {
                                    case "z":
                                        break;

                                }
                            }
                            else if (weather_cmb.Text == "Wet")
                            {
                                switch (linkLabel1.Text = "enjoy from life and stay at home")
                                {
                                    case "zz":
                                        break;

                                }
                            }

                            //===========================================================================================

                        }


                    }
          
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }





        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void linkLabel1_MouseClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (linkLabel1.Text == "please dance for a quarter")
                {

                    Form2 frm2 = new Form2();
                    frm2.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "please run for 2 min")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }

                else if (linkLabel1.Text == "find a friend for yourself")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with an expert or psychologist")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with your teacher rapidly")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "take three deep breath,continue carefully")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "take three deep breath and dont make a decision")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "take three deep breath and meditate")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "meditate and have a fun")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with a Motivational Consultant")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with a Economic Consultant")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "Hopeful more and more,Try Uninterrupted")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with an expert")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with a psychologist first")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with an expert psychologist")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with an expert consultant")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "Listen to a happy music")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a cup of tea,then take decision")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "visit a doctor to be better then continue")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "Health is more important,then continue")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "visit a doctor,keep calm,drink your drugs on time")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dance for a quarter")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "rest more")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go to a CASINO or Disco and dance")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a cup of coffee")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "sleep enough at night and listen to a happy music")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "have a plan for your future")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "check your notes,read success books")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "no pain,no gain")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be patient,The situation will be change")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "find for yourself a companion")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "find for yourself a mate")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "leave it and find your interesting thing")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "leave it and find your interesting sport")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do right thing and consult with an expert")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "change your view and rest your mind")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "change your view and rest your mind and consult")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "attend to your PSYCHE,consult with an expert")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "attend to your PSYCHE,Meditate")
                {
                    Form3 frm3 = new Form3();
                    frm3.Show();
                    this.Hide();
                }

                else if (linkLabel1.Text == "dance a quarter near the coastline")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if(linkLabel1.Text== "stay at home and drink enough water")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if(linkLabel1.Text== "go outside and walk for 20 minute")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }

                else if(linkLabel1.Text== "wear a warm cloth")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if(linkLabel1.Text== "eat warm soup or drink hot chocolate")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if(linkLabel1.Text== "go outside and dance near the river")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text== "dance near the sea and swim")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text== "drink enough water")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text== "put on warm cloth and go outside")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text== "go for walking outside and take deep breathe")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text== "stay at home and drink two cup of coffee(only 2 cup )")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and walk for 20 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside at night and study at home")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go to a club and dance 1 hour")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and become wet,Enjoy From Life")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do Meditate")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drive slowly and carefully")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,Enjoy at home")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and drink a cup of tea")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and enjoy from walking")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "enjoy from life and stay at home")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "find a friend for yourself")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dance a quarter near the coastline with your friend")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay at home and drink enough water and study")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "wear a warm cloth and drink a cup of coffee")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and dance near the river 20 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dance near the sea and swim 20 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside at night and study at home")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dance 10 min at home,take a bath,sleep enough")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "be careful and dont go outside")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and enjoy from walking for 1 hour")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "enjoy from life and stay at home")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go to a casino or disco and enjoy")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "wear a warm cloth and go to a disco")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "go outside and dance near the river or sea")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "go outside at night")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do Meditate 15 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,Enjoy at hotel")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with an expert or psychologist")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a glass of lemon juice")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside with your cosultant and walk for 20 minute")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "take a break and drink 2 cup of tea(only 2 cup)")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay in office and draw future schedule & wear a warm cloth")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "open a window and take breathe")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside with your team and hold a meeting")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "accompany with your consultant")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go for walking outside and take deep breathe for 20 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay at office and drink two cup of coffee(only 2 cup )")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and walk for 20 min with your Customer")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "stay at office and drink a glass of juice")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a cup of tea")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dont make a decision,cosult with your cosultant")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do Meditate at office")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dont make a sensitive decision")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,Enjoy at office")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a glass of orange juice")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "enjoy from life and stay at office")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "enjoy from life and stay at hotel")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with your teacher rapidly")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay at home and exercize at home")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a lot of fruit")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,Enjoy at gym")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "dont go outside and drink a lot of water")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and enjoy from walking")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "accompany with your consultant")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay at office and drink enough water")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink hot chocolate")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "open the window and take three deep breathe")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "relax your body and sit down")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "go and swim after work")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "put on warm cloth and go outside for 10 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go for walking outside and take deep breathe")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "watch T.V for 20 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and become wet for 10 min,Enjoy From Life")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do Meditate on your seat for 5 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "cosult with your psychologist")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and drink a cup of tea with your team")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "walk an breathe for 3 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "enjoy from your life and do meditate")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "take three deep breath and meditate")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "meditate and have a fun")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay at home and drink enough water")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "wear a warm cloth and dance in a club")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "watch a documentary movie")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,listen to a happy music")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,eat necessary food")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do meditation on your seat")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do meditate 5 min on your seat,paly a music")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                }
                else if (linkLabel1.Text == "go outside and dance near the river after work")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "put on warm cloth and review your schedule")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go for walking outside after work and take deep breathe")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "stay at office and drink two cup of coffee(only 2 cup )")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "meditate 5 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside at night and review your schedule")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "go outside with your customer")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "do Meditate for 5 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "listen to a happy music")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "do your interesting work")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "listen to a funny music")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                }
                else if (linkLabel1.Text == "enjoy from life and Held up a seminar")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with a Motivational Consultant")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "consult with a Economic Consultant")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "stay at office and drink enough water,dance 30 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "walk for 20 min")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "wear a warm cloth and write your thought")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "Its possible and you can,Listen to a few happy music")
                {
                    Form2 frm2 = new Form2();
                    frm2.Show();
                }
                
                else if (linkLabel1.Text == "go for walking outside and take deep breathe if possible")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "walk and think correctly")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go outside and become wet,Enjoy From Life,you will become only wet")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "go to a restaurant and drink a cup of tea with your customer")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go to a think room with your customer")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "Hopeful more and more,Try Uninterrupted")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "consult with an expert")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "be careful and dont go outside,Enjoy at think room")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "walk a quarter near the coastline")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "enjoy from life and stay at Hotel")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "walk or spend a quarter near the coastline")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go to a disco at night")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "eat some fresh fruit")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();

                }
                else if (linkLabel1.Text == "continue to exercise")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "go to a CASINO or Disco and dance")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "be careful and dont go outside,Enjoy at Hotel")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
                else if (linkLabel1.Text == "drink a cup of coffee")
                {
                    Form5 frm5 = new Form5();
                    frm5.Show();
                    this.Hide();
                }
               
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }


        private void comboBox1_Enter(object sender, EventArgs e)
        {
            System.Globalization.CultureInfo language = new System.Globalization.CultureInfo("en-us");
            InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
        }

        private void comboBox2_Enter(object sender, EventArgs e)
        {
            System.Globalization.CultureInfo language = new System.Globalization.CultureInfo("en-us");
            InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
        }

        private void linkLabel3_MouseClick(object sender, MouseEventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            this.datetimelbl.Text = dateTime.ToString();

        }

        private void linkLabel4_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.accuweather.com/");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form4 frm4 = new Form4();
            frm4.Show();
            this.Hide();


        }

        private void MobileNum_tb_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void Add_btn_Click(object sender, EventArgs e)
        {
            Form4 frm = new Form4();
            frm.Show();
            this.Hide();
        }

        private void list_of_experience_period_TextChanged(object sender, EventArgs e)
        {
            if (list_of_experience_period.Text != string.Empty)
            {
                if (list_of_experience_period.Text == "1 week")
                {
                    linkLabel1.BringToFront();
                    linkLabel1.Visible = true;
                }
            }
        }
    }

}
