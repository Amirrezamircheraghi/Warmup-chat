﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace companion1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void linkLabel1_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.google.com/");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel2_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.drpals.com/");
        }

        private void linkLabel4_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.doctorslounge.com/psychiatry/forums/archive.htm");
        }

        private void linkLabel3_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.linkedin.com/title/motivational-speaker"); 
        }

        private void linkLabel8_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.success.com/article/25-books-for-success"); 
        }

        private void linkLabel7_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.how-to-meditate.org/");
        }

        private void linkLabel6_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.linkedin.com/title/economic-consultant"); 
        }

        private void linkLabel5_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("https://doctorbase.com/ask"); 
        }

        private void linkLabel16_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.doctorondemand.com/medical/?utm_content=dtlpcontrol&gclid=COrRnpWrvM8CFQNehgodEj0F8w");
        }

        private void linkLabel15_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.mappingyourfuture.org/");
        }

        private void linkLabel14_MouseClick(object sender, MouseEventArgs e)
        {
           System.Diagnostics.Process.Start("https://evernote.com/"); 
        }

        private void linkLabel13_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.success.com/article/25-books-for-success");
        }

        private void linkLabel12_MouseClick(object sender, MouseEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.match.com/cpx/en-us/match/IndexPage/");
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
    }
}
