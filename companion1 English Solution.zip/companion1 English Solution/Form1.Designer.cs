﻿namespace companion1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.datetimelbl = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.weather_cmb = new System.Windows.Forms.ComboBox();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.label6 = new System.Windows.Forms.Label();
            this.Add_btn = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dustan_MoshakhasatBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.list_of_experience_period = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dustan_MoshakhasatBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(121, 382);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Answer :";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(36, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Please answer to questions :";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(36, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 37);
            this.label4.TabIndex = 13;
            this.label4.Text = "What are you doing ?\r\n";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Maroon;
            this.label3.Location = new System.Drawing.Point(35, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 23);
            this.label3.TabIndex = 12;
            this.label3.Text = "How are you ?";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.comboBox2.ForeColor = System.Drawing.Color.Maroon;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Education",
            "Sports",
            "Travel",
            "Bussiness",
            "Health"});
            this.comboBox2.Location = new System.Drawing.Point(218, 116);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(207, 24);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.Tag = "";
            this.comboBox2.Enter += new System.EventHandler(this.comboBox2_Enter);
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.comboBox1.ForeColor = System.Drawing.Color.Maroon;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Sensitive",
            "Tender",
            "Passionate",
            "‌=========================",
            "Irritated",
            "Nervous",
            "Provoked",
            "=========================",
            "Bored‌",
            "=========================",
            "Discouraged",
            "=========================",
            "Doubtful",
            "=========================",
            "Uncertain",
            "Disgusted",
            "Perplexed",
            "Empty",
            "Vulnerable",
            "Bad",
            "=========================",
            "Neutral",
            "Insensitive",
            "=========================",
            "Fearful",
            "Terrified",
            "Panic",
            "=========================",
            "Tearful",
            "Sorrowful",
            "Grief",
            "Upset",
            "=========================",
            "Pained",
            "=========================",
            "Weary",
            "=========================",
            "Anxious",
            "Anguish",
            "Concerned",
            "Worried",
            "Uneasy",
            "Distressed",
            "=========================",
            "Aching",
            "Lonely",
            "Disinterested\t",
            "Pessimistic",
            "Preoccupied",
            "Mournful"});
            this.comboBox1.Location = new System.Drawing.Point(218, 69);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(207, 24);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Enter += new System.EventHandler(this.comboBox1_Enter);
            // 
            // linkLabel1
            // 
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.Font = new System.Drawing.Font("Palatino Linotype", 14F, System.Drawing.FontStyle.Bold);
            this.linkLabel1.ForeColor = System.Drawing.Color.Maroon;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.Crimson;
            this.linkLabel1.Location = new System.Drawing.Point(198, 379);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(622, 38);
            this.linkLabel1.TabIndex = 23;
            this.linkLabel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel1_MouseClick);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(443, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(232, 28);
            this.label5.TabIndex = 29;
            this.label5.Text = "Date && Time :";
            // 
            // datetimelbl
            // 
            this.datetimelbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.datetimelbl.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetimelbl.ForeColor = System.Drawing.Color.Maroon;
            this.datetimelbl.Location = new System.Drawing.Point(546, 17);
            this.datetimelbl.Name = "datetimelbl";
            this.datetimelbl.Size = new System.Drawing.Size(232, 28);
            this.datetimelbl.TabIndex = 30;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Maroon;
            this.label8.Location = new System.Drawing.Point(508, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 47);
            this.label8.TabIndex = 34;
            this.label8.Text = "|\r\n|";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(36, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(223, 37);
            this.label9.TabIndex = 35;
            this.label9.Text = "How is your region wether ?";
            // 
            // weather_cmb
            // 
            this.weather_cmb.AllowDrop = true;
            this.weather_cmb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.weather_cmb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.weather_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.weather_cmb.ForeColor = System.Drawing.Color.Maroon;
            this.weather_cmb.FormattingEnabled = true;
            this.weather_cmb.Items.AddRange(new object[] {
            "Equatorial",
            "Extreme (hot / cold)",
            "Moderate",
            "Cool",
            "Cold",
            "Freezing",
            "Mild",
            "Sunny",
            "Humid",
            "damp",
            "moist",
            "Dry",
            "Warm",
            "Hot",
            "Scorcher",
            "Mist",
            "Clear",
            "Stormy",
            "Changeable",
            "Muggy",
            "Stifling",
            "Cloudy",
            "Rainy",
            "Windy",
            "Freeze",
            "Foggy",
            "Thunder and lighting",
            "Hurricane – typhoon",
            "Hailstone",
            "Hailstorm",
            "Thunderstorm",
            "Snow",
            "Sunshine",
            "Wet"});
            this.weather_cmb.Location = new System.Drawing.Point(258, 187);
            this.weather_cmb.Name = "weather_cmb";
            this.weather_cmb.Size = new System.Drawing.Size(177, 24);
            this.weather_cmb.TabIndex = 2;
            this.weather_cmb.Tag = "";
            this.weather_cmb.Text = "Select or Search in :";
            // 
            // linkLabel4
            // 
            this.linkLabel4.AccessibleRole = System.Windows.Forms.AccessibleRole.Sound;
            this.linkLabel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel4.ForeColor = System.Drawing.Color.Maroon;
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel4.LinkColor = System.Drawing.Color.MediumBlue;
            this.linkLabel4.Location = new System.Drawing.Point(446, 188);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(308, 23);
            this.linkLabel4.TabIndex = 40;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "http://www.accuweather.com/";
            this.linkLabel4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel4_MouseClick);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(343, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 39);
            this.label6.TabIndex = 49;
            this.label6.Text = "|\r\n|";
            // 
            // Add_btn
            // 
            this.Add_btn.ForeColor = System.Drawing.Color.Maroon;
            this.Add_btn.Location = new System.Drawing.Point(346, 230);
            this.Add_btn.Name = "Add_btn";
            this.Add_btn.Size = new System.Drawing.Size(81, 26);
            this.Add_btn.TabIndex = 51;
            this.Add_btn.Text = "Show";
            this.Add_btn.UseVisualStyleBackColor = true;
            this.Add_btn.Click += new System.EventHandler(this.Add_btn_Click);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Maroon;
            this.label11.Location = new System.Drawing.Point(36, 234);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(348, 20);
            this.label11.TabIndex = 50;
            this.label11.Text = "Names of persons && their Mobile Number :";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackgroundImage = global::companion1.Properties.Resources.Log_Out;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Location = new System.Drawing.Point(848, 451);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 48);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button3.ForeColor = System.Drawing.Color.Maroon;
            this.button3.Location = new System.Drawing.Point(39, 362);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 55);
            this.button3.TabIndex = 3;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dustan_MoshakhasatBindingSource
            // 
            this.dustan_MoshakhasatBindingSource.DataMember = "dustan_Moshakhasat";
            // 
            // list_of_experience_period
            // 
            this.list_of_experience_period.ForeColor = System.Drawing.Color.Maroon;
            this.list_of_experience_period.FormattingEnabled = true;
            this.list_of_experience_period.Location = new System.Drawing.Point(398, 383);
            this.list_of_experience_period.Name = "list_of_experience_period";
            this.list_of_experience_period.Size = new System.Drawing.Size(136, 21);
            this.list_of_experience_period.TabIndex = 54;
            this.list_of_experience_period.Visible = false;
            this.list_of_experience_period.TextChanged += new System.EventHandler(this.list_of_experience_period_TextChanged);
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Maroon;
            this.label12.Location = new System.Drawing.Point(219, 384);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(177, 20);
            this.label12.TabIndex = 55;
            this.label12.Text = "Experience Duration :";
            this.label12.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(931, 511);
            this.ControlBox = false;
            this.Controls.Add(this.label12);
            this.Controls.Add(this.list_of_experience_period);
            this.Controls.Add(this.Add_btn);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.datetimelbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.weather_cmb);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Enter Your Situations";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dustan_MoshakhasatBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label datetimelbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox weather_cmb;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.Label label6;
        //private data.dataset.DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource dustan_MoshakhasatBindingSource;
        private System.Windows.Forms.Button Add_btn;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox list_of_experience_period;
        private System.Windows.Forms.Label label12;
        // private data.dataset.DataSet1TableAdapters.dustan_MoshakhasatTableAdapter dustan_MoshakhasatTableAdapter;
        // private data.dataset.DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
    }
}

