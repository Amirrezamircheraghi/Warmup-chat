﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace companion1
{
    public partial class About_Me : Form
    {
        public About_Me()
        {
            InitializeComponent();
        }
    }
}
