﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace companion1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
             OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "MP3 Files|*.mp3|MP4 Files|*.mp4|wmv Files|*.wmv";
            ofd.Title = "please select your files";
            ofd.DefaultExt="";
            if(ofd.ShowDialog()==DialogResult.OK)
               {
                   axWindowsMediaPlayer1.URL = ofd.FileName;
               }
            }   
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }
    }
}
