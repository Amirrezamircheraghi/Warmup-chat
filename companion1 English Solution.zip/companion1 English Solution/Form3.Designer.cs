﻿namespace companion1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel4 = new System.Windows.Forms.LinkLabel();
            this.linkLabel5 = new System.Windows.Forms.LinkLabel();
            this.linkLabel6 = new System.Windows.Forms.LinkLabel();
            this.linkLabel7 = new System.Windows.Forms.LinkLabel();
            this.linkLabel8 = new System.Windows.Forms.LinkLabel();
            this.linkLabel12 = new System.Windows.Forms.LinkLabel();
            this.linkLabel13 = new System.Windows.Forms.LinkLabel();
            this.linkLabel14 = new System.Windows.Forms.LinkLabel();
            this.linkLabel15 = new System.Windows.Forms.LinkLabel();
            this.linkLabel16 = new System.Windows.Forms.LinkLabel();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // linkLabel1
            // 
            this.linkLabel1.AllowDrop = true;
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel1.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.Location = new System.Drawing.Point(12, 20);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(212, 31);
            this.linkLabel1.TabIndex = 0;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Search all things in Google";
            this.linkLabel1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel1_MouseClick);
            // 
            // button1
            // 
            this.button1.AllowDrop = true;
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.BackgroundImage = global::companion1.Properties.Resources.Log_Out;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.button1.Location = new System.Drawing.Point(210, 459);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 58);
            this.button1.TabIndex = 5;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AllowDrop = true;
            this.linkLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel2.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel2.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel2.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel2.Location = new System.Drawing.Point(12, 51);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(212, 31);
            this.linkLabel2.TabIndex = 6;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Consult - Psychology";
            this.linkLabel2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel2_MouseClick);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AllowDrop = true;
            this.linkLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel3.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel3.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel3.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel3.Location = new System.Drawing.Point(12, 113);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(381, 31);
            this.linkLabel3.TabIndex = 8;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "Motivational speaker";
            this.linkLabel3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel3_MouseClick);
            // 
            // linkLabel4
            // 
            this.linkLabel4.AllowDrop = true;
            this.linkLabel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel4.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel4.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel4.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel4.Location = new System.Drawing.Point(12, 82);
            this.linkLabel4.Name = "linkLabel4";
            this.linkLabel4.Size = new System.Drawing.Size(453, 31);
            this.linkLabel4.TabIndex = 7;
            this.linkLabel4.TabStop = true;
            this.linkLabel4.Text = "Psychiatry Archive";
            this.linkLabel4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel4_MouseClick);
            // 
            // linkLabel5
            // 
            this.linkLabel5.AllowDrop = true;
            this.linkLabel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel5.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel5.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel5.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel5.Location = new System.Drawing.Point(12, 236);
            this.linkLabel5.Name = "linkLabel5";
            this.linkLabel5.Size = new System.Drawing.Size(212, 31);
            this.linkLabel5.TabIndex = 12;
            this.linkLabel5.TabStop = true;
            this.linkLabel5.Text = "Doctorbase and Topics";
            this.linkLabel5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel5_MouseClick);
            // 
            // linkLabel6
            // 
            this.linkLabel6.AllowDrop = true;
            this.linkLabel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel6.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel6.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel6.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel6.Location = new System.Drawing.Point(12, 205);
            this.linkLabel6.Name = "linkLabel6";
            this.linkLabel6.Size = new System.Drawing.Size(381, 31);
            this.linkLabel6.TabIndex = 11;
            this.linkLabel6.TabStop = true;
            this.linkLabel6.Text = "Economic consultant";
            this.linkLabel6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel6_MouseClick);
            // 
            // linkLabel7
            // 
            this.linkLabel7.AllowDrop = true;
            this.linkLabel7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel7.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel7.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel7.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel7.Location = new System.Drawing.Point(12, 174);
            this.linkLabel7.Name = "linkLabel7";
            this.linkLabel7.Size = new System.Drawing.Size(252, 31);
            this.linkLabel7.TabIndex = 10;
            this.linkLabel7.TabStop = true;
            this.linkLabel7.Text = "How to meditate";
            this.linkLabel7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel7_MouseClick);
            // 
            // linkLabel8
            // 
            this.linkLabel8.AllowDrop = true;
            this.linkLabel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel8.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel8.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel8.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel8.Location = new System.Drawing.Point(12, 143);
            this.linkLabel8.Name = "linkLabel8";
            this.linkLabel8.Size = new System.Drawing.Size(392, 31);
            this.linkLabel8.TabIndex = 9;
            this.linkLabel8.TabStop = true;
            this.linkLabel8.Text = "Think and Grow Rich";
            this.linkLabel8.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel8_MouseClick);
            // 
            // linkLabel12
            // 
            this.linkLabel12.AllowDrop = true;
            this.linkLabel12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel12.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel12.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel12.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel12.Location = new System.Drawing.Point(12, 393);
            this.linkLabel12.Name = "linkLabel12";
            this.linkLabel12.Size = new System.Drawing.Size(392, 31);
            this.linkLabel12.TabIndex = 17;
            this.linkLabel12.TabStop = true;
            this.linkLabel12.Text = "Start dating";
            this.linkLabel12.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel12_MouseClick);
            // 
            // linkLabel13
            // 
            this.linkLabel13.AllowDrop = true;
            this.linkLabel13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel13.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel13.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel13.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel13.Location = new System.Drawing.Point(12, 363);
            this.linkLabel13.Name = "linkLabel13";
            this.linkLabel13.Size = new System.Drawing.Size(392, 31);
            this.linkLabel13.TabIndex = 16;
            this.linkLabel13.TabStop = true;
            this.linkLabel13.Text = "Success";
            this.linkLabel13.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel13_MouseClick);
            // 
            // linkLabel14
            // 
            this.linkLabel14.AllowDrop = true;
            this.linkLabel14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel14.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel14.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel14.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel14.Location = new System.Drawing.Point(12, 332);
            this.linkLabel14.Name = "linkLabel14";
            this.linkLabel14.Size = new System.Drawing.Size(212, 31);
            this.linkLabel14.TabIndex = 15;
            this.linkLabel14.TabStop = true;
            this.linkLabel14.Text = "Remember every things";
            this.linkLabel14.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel14_MouseClick);
            // 
            // linkLabel15
            // 
            this.linkLabel15.AllowDrop = true;
            this.linkLabel15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel15.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel15.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel15.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel15.Location = new System.Drawing.Point(12, 301);
            this.linkLabel15.Name = "linkLabel15";
            this.linkLabel15.Size = new System.Drawing.Size(282, 31);
            this.linkLabel15.TabIndex = 14;
            this.linkLabel15.TabStop = true;
            this.linkLabel15.Text = "Mapping Your Future";
            this.linkLabel15.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel15_MouseClick);
            // 
            // linkLabel16
            // 
            this.linkLabel16.AllowDrop = true;
            this.linkLabel16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel16.Font = new System.Drawing.Font("Tahoma", 12F);
            this.linkLabel16.ForeColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.linkLabel16.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel16.Location = new System.Drawing.Point(12, 270);
            this.linkLabel16.Name = "linkLabel16";
            this.linkLabel16.Size = new System.Drawing.Size(295, 31);
            this.linkLabel16.TabIndex = 13;
            this.linkLabel16.TabStop = true;
            this.linkLabel16.Text = "FOR HEALTHCARE PROFESSIONALS ";
            this.linkLabel16.MouseClick += new System.Windows.Forms.MouseEventHandler(this.linkLabel16_MouseClick);
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button3.BackColor = System.Drawing.Color.SkyBlue;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.button3.Location = new System.Drawing.Point(126, 459);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(78, 58);
            this.button3.TabIndex = 18;
            this.button3.Text = "Enter Situation";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(296, 529);
            this.ControlBox = false;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.linkLabel12);
            this.Controls.Add(this.linkLabel13);
            this.Controls.Add(this.linkLabel14);
            this.Controls.Add(this.linkLabel15);
            this.Controls.Add(this.linkLabel16);
            this.Controls.Add(this.linkLabel5);
            this.Controls.Add(this.linkLabel6);
            this.Controls.Add(this.linkLabel7);
            this.Controls.Add(this.linkLabel8);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.linkLabel4);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.linkLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel4;
        private System.Windows.Forms.LinkLabel linkLabel5;
        private System.Windows.Forms.LinkLabel linkLabel6;
        private System.Windows.Forms.LinkLabel linkLabel7;
        private System.Windows.Forms.LinkLabel linkLabel8;
        private System.Windows.Forms.LinkLabel linkLabel12;
        private System.Windows.Forms.LinkLabel linkLabel13;
        private System.Windows.Forms.LinkLabel linkLabel14;
        private System.Windows.Forms.LinkLabel linkLabel15;
        private System.Windows.Forms.LinkLabel linkLabel16;
        private System.Windows.Forms.Button button3;
    }
}